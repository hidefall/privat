from xonsh.main import main

main()
